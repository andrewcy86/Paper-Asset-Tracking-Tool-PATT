<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'wppatt_Ajax' ) ) :
    
    /**
     * Ajax class for wppatt.
     * @class wppatt_Ajax
     */
    class wppatt_Ajax {
 
				
		}
    
endif;

new wppatt_Ajax();