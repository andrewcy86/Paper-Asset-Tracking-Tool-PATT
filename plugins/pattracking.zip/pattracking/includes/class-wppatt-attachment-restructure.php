<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if( !class_exists('wppatt_Attach_Restruct') ) :
    
    final class wppatt_Attach_Restruct {
        
  
    }

endif;

wppatt_Attach_Restruct::init();