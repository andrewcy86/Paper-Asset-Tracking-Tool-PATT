<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'wppattWPCron' ) ) :
   
   final class wppattWPCron {
       public function wppatt_cron_job() {

       }    
   }
endif;