<?php
if ( ! defined( 'ABSPATH' ) ) {
  exit; // Exit if accessed directly
}

if ( ! class_exists( 'wppatt_Frontend' ) ) :
  
  final class wppatt_Frontend {
    
  }
  
endif;

new wppatt_Frontend();