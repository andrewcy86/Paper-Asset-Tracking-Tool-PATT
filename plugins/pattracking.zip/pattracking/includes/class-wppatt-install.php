<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! class_exists( 'wppatt_Install' ) ) :

  final class wppatt_Install {

		}

endif;

new wppatt_Install();
